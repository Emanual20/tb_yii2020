length-of-selected
==================

用鼠标在界面中选定一段文本，右键，在弹出菜单里点击Length of selected text即可
